package game2;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;


public class ColorTrackingGame2 extends JPanel implements ActionListener{ //implements ActionListener    {
	JLabel name = new JLabel("Color Tracking Game",SwingConstants.CENTER);
	Random rnd = new Random();
	JButton initialBT = new JButton("");
	String initial = "";
	String Top = "";
	JPanel topPanel = new JPanel();
	JPanel topPanel2 = new JPanel();
	JPanel bottomPanel = new JPanel();
	Font myfont = new Font("SansSerif",Font.BOLD,40);
	
	int remainingTime = 40;
	int point = 0;
	int goal = 15;
	JLabel time = new JLabel("Time: "+remainingTime);
	JLabel find = new JLabel("Find: ");
	JLabel pointer = new JLabel("Point: "+point);
	JLabel goaler = new JLabel("Goal: "+goal);
	ArrayList<JButton> buttons = new ArrayList<>();
	ArrayList<Color> colors = new ArrayList<>();
	ArrayList<Character> letters = new ArrayList<>();
	Timer timer = new Timer(1000,new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			remainingTime --;
			time.setText("Time: "+""+remainingTime);
			if (remainingTime == 0) {
	            timer.stop();
	            JOptionPane.showMessageDialog(ColorTrackingGame2.this, "Time's up! You scored " + point + " points.");
	        }
			
		}
	});
	
	public ColorTrackingGame2(){
		super();
		timer.start();
		randomTop();
		setLayout(new BorderLayout());
		topPanel.setLayout(new GridLayout(2,1));
		topPanel.add(name);
		
		
		topPanel2.setLayout(new FlowLayout());
		topPanel2.add(time);
		topPanel2.add(find);
		topPanel2.add(initialBT);
		topPanel2.add(pointer);
		topPanel2.add(goaler);
		topPanel.add(topPanel2);
		
		add(topPanel,BorderLayout.NORTH);
		add(bottomPanel,BorderLayout.CENTER);
		
		initialBT.addActionListener(this);
		randomColor();
		for (int i = 0; i < 160; i++){
			char randomLetter = letters.get(rnd.nextInt(letters.size()));
			initial = String.valueOf(randomLetter);
			JButton jb = new JButton(initial);
			Color newColor = colors.get(rnd.nextInt(colors.size()));
			jb.setBackground(newColor);
			buttons.add(jb);
			bottomPanel.add(jb);
			jb.addActionListener(this);
		}
	
	}
	
	public void randomColor() {
		colors.add(Color.RED);
		colors.add(Color.PINK);
		colors.add(Color.YELLOW);
		colors.add(Color.BLUE);
		colors.add(Color.ORANGE);
		String alphabet = "ABCD";
		{
			for (char c : alphabet.toCharArray()) {
				letters.add(c);
			}
			for (JButton button : buttons){
				char randomLetter = letters.get(rnd.nextInt(letters.size()));
				String newLabel = String.valueOf(randomLetter);
				Color newColor = colors.get(rnd.nextInt(colors.size()));
				 button.setText(newLabel);
				 button.setBackground(newColor);
			}}
				
	}
	public void randomTop() {
		ArrayList<Color> colors = new ArrayList<>();
		colors.add(Color.RED);
		colors.add(Color.PINK);
		colors.add(Color.YELLOW);
		colors.add(Color.BLUE);
		colors.add(Color.ORANGE);
		Color randomColor = colors.get(rnd.nextInt(colors.size()));
		String alphabet = "ABCD";
		ArrayList<Character> letters = new ArrayList<>();{

			for (char c : alphabet.toCharArray()) {
				letters.add(c);
			}
		char randomLetter = letters.get(rnd.nextInt(letters.size()));
		Top = String.valueOf(randomLetter);
		initialBT.setText(Top);
		initialBT.setBackground(randomColor);
		}
	}
	
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setFont(myfont);	
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		 if (point == goal) {
			timer.stop();
			JOptionPane.showMessageDialog(this, "You win! You reached the goal of " + goal + " points.");
		
		}else {
	    if (e.getActionCommand().equals(initialBT.getActionCommand())) {
	        JButton clickedButton = (JButton) e.getSource();
	        if (clickedButton.getBackground().equals(initialBT.getBackground())) {
	            point++;
	            randomTop();
	            pointer.setText("Point: " +point);
	            repaint();
	        } else {
	            point--;
	            pointer.setText("Point: " + point);
	            repaint();
	        }
	    } else {
	        point--;
	        randomTop();
	        pointer.setText("Point: " + point);
	        repaint();
	    }}
	    for (JButton button : buttons) {
	        char randomLetter = letters.get(rnd.nextInt(letters.size()));
	        String newLabel = String.valueOf(randomLetter);
	        Color newColor = colors.get(rnd.nextInt(colors.size()));
	        button.setText(newLabel);
	        button.setBackground(newColor);
	    }
	    remainingTime--;
	    time.setText("Time: " + remainingTime);
	    if (remainingTime == 0) {
            timer.stop();
            JOptionPane.showMessageDialog(this, "Time's up! You scored " + point + " points.");
        }
	}
}
		
	



	


