import java.awt.Color;

import javax.swing.JFrame;

import game.ColorTrackingGame;
import game2.ColorTrackingGame2;

public class Main {

	public static void main(String[] args) {
		ColorTrackingGame test = new ColorTrackingGame();
		//JFrame frame1 = new JFrame("Color Tracking game");
		//frame1.add(new ColorTrackingGame2());
		//frame1.setResizable(false);
		//frame1.setSize(500,650);
		//frame1.setVisible(false);

	}

}
